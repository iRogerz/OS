import java.io.*;
import java.net.*;

public class EchoServer {

    public static void main(String[] args) throws IOException {

        ServerSocket server = new ServerSocket(1000);
        while (true) {
            Socket client = server.accept();
            BufferedReader r = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter w = new PrintWriter(client.getOutputStream(), true);
            w.println("Welcome to Echo Server. Enter 'bye' to quit.");
            String line;
            do {
                line = r.readLine();
                System.out.println(line);
                if (line != null)
                    w.println(line);
            } while (!line.trim().equalsIgnoreCase("bye"));
            client.close();
            break;
        }
    }
}